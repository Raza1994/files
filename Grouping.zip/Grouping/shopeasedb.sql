-- Step 1: Create the Database
CREATE DATABASE ShopEaseDB;
GO

-- Step 2: Use the Database
USE ShopEaseDB;
GO

-- Step 3: Create Tables

-- Customers Table
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY,
    CustomerName VARCHAR(100),
    City VARCHAR(100),
    Age INT
);

-- Products Table
CREATE TABLE Products (
    ProductID INT PRIMARY KEY,
    ProductName VARCHAR(100),
    Category VARCHAR(50),
    Price DECIMAL(10,2)
);

-- Orders Table
CREATE TABLE Orders (
    OrderID INT PRIMARY KEY,
    CustomerID INT,
    ProductID INT,
    Quantity INT,
    OrderDate DATE,
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
    FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
);

-- Step 4: Insert Data

-- Customers
INSERT INTO Customers VALUES
(1, 'Emma Johnson', 'New York', 34),
(2, 'Liam Smith', 'Chicago', 28),
(3, 'Olivia Brown', 'New York', 45),
(4, 'Noah Davis', 'San Francisco', 30),
(5, 'Ava Wilson', 'Chicago', 22),
(6, 'Elijah Moore', 'Seattle', 40),
(7, 'Sophia Taylor', 'San Francisco', 35);

-- Products
INSERT INTO Products VALUES
(101, 'Laptop', 'Electronics', 1200.00),
(102, 'Wireless Mouse', 'Electronics', 25.50),
(103, 'Office Chair', 'Furniture', 150.00),
(104, 'Desk Lamp', 'Furniture', 45.00),
(105, 'Notebook', 'Stationery', 3.75),
(106, 'Pen Set', 'Stationery', 12.00);

-- Orders
INSERT INTO Orders VALUES
(1001, 1, 101, 1, '2024-05-01'),
(1002, 1, 102, 2, '2024-05-02'),
(1003, 2, 103, 1, '2024-05-03'),
(1004, 3, 101, 1, '2024-05-04'),
(1005, 3, 105, 10, '2024-05-05'),
(1006, 4, 104, 2, '2024-05-06'),
(1007, 5, 106, 3, '2024-05-07'),
(1008, 6, 102, 1, '2024-05-08'),
(1009, 7, 103, 1, '2024-05-09'),
(1010, 7, 105, 5, '2024-05-10'),
(1011, 2, 106, 4, '2024-05-11'),
(1012, 4, 101, 1, '2024-05-12'),
(1013, 5, 104, 1, '2024-05-13'),
(1014, 6, 105, 7, '2024-05-14'),
(1015, 1, 103, 1, '2024-05-15');

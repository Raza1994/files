
-- Step 1: Create the Database
CREATE DATABASE SkillForgeDB;
GO

-- Step 2: Use the Database
USE SkillForgeDB;
GO

-- Step 3: Create Tables

-- Courses Table
CREATE TABLE Courses (
    CourseID INT PRIMARY KEY,
    CourseName VARCHAR(100),
    DurationWeeks INT,
    Fee INT
);

-- Students Table
CREATE TABLE Students (
    StudentID INT PRIMARY KEY,
    Name VARCHAR(100),
    City VARCHAR(100),
    Age INT
);

-- Enrollments Table
CREATE TABLE Enrollments (
    EnrollmentID INT PRIMARY KEY,
    StudentID INT,
    CourseID INT,
    EnrollDate DATE,
    Status VARCHAR(20),
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID),
    FOREIGN KEY (CourseID) REFERENCES Courses(CourseID)
);

-- Step 4: Insert Data

-- Courses
INSERT INTO Courses VALUES 
(101, 'Python for Beginners', 6, 5000),
(102, 'Data Analytics with Excel', 4, 4000),
(103, 'Power BI Essentials', 5, 4500),
(104, 'SQL Fundamentals', 4, 3000),
(105, 'Tableau for Starters', 5, 4200);

-- Students
INSERT INTO Students VALUES 
(1, 'Alice Tan', 'Singapore', 22),
(2, 'Rahul Nair', 'Mumbai', 25),
(3, 'Mei Lin', 'Singapore', 28),
(4, 'John Lim', 'Kuala Lumpur', 24),
(5, 'Sara Ng', 'Penang', 23),
(6, 'Dev Sharma', 'Delhi', 29),
(7, 'Kevin Lee', 'Singapore', 26),
(8, 'Aditi Rao', 'Mumbai', 27),
(9, 'Victor Tan', 'Kuala Lumpur', 24);

-- Enrollments
INSERT INTO Enrollments VALUES 
(1001, 1, 101, '2024-05-01', 'Enrolled'),
(1002, 2, 102, '2024-05-03', 'Completed'),
(1003, 3, 101, '2024-05-05', 'Completed'),
(1004, 3, 104, '2024-05-10', 'Enrolled'),
(1005, 4, 103, '2024-05-15', 'Dropped'),
(1006, 5, 102, '2024-05-18', 'Enrolled'),
(1007, 6, 101, '2024-05-21', 'Completed'),
(1008, 7, 105, '2024-06-01', 'Enrolled'),
(1009, 8, 104, '2024-06-02', 'Enrolled'),
(1010, 9, 105, '2024-06-04', 'Enrolled');
